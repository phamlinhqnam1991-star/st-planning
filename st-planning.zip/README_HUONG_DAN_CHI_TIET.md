# ST Planning V438 — Chuyển FULL PostgreSQL từ Supabase sang Aiven

## Mục tiêu đã chốt

Giai đoạn này **không giảm database trước**. Chuyển nguyên trạng database nghiệp vụ hiện tại (~600 MB) sang Aiven trước, xác nhận app chạy ổn, sau đó mới làm Phase 2 dọn history/index/routing.

Luồng:

`Supabase PostgreSQL OLD (~600 MB)` → `pg_dump FULL public` → `Aiven PostgreSQL NEW` → `verify row count` → `Vercel V438 dùng DATABASE_URL=Aiven`.

Không thay Planning Chain, Recipe, Batch, Schedule, Chemical Line, Masking/Unmasking, Production, Dashboard.

> Database runtime là **Aiven PostgreSQL**. Từ V478, Login/RBAC/Session cũng nằm trên Aiven. Supabase chỉ còn có thể xuất hiện ở các luồng Storage/import cũ nếu bạn vẫn dùng chúng; không dùng Supabase Auth cho account ST Planning.

---

## 1. Tạo Aiven PostgreSQL Free

1. Đăng nhập Aiven Console.
2. Tạo Project.
3. Create Service → PostgreSQL.
4. Chọn Free Plan.
5. Chọn region gần hệ thống của bạn nhất.
6. Đợi service trạng thái Running.
7. Mở `Overview / Connect` và copy **Service URI**.

Aiven URI thường dạng:

`postgres://avnadmin:PASSWORD@HOST:PORT/defaultdb?sslmode=require`

Aiven Free hiện có 1 CPU, 1 GB RAM, 1 GB disk và `max_connections=20`, không có built-in connection pooling. Vì vậy V438 mặc định `DB_POOL_MAX=1` trên Vercel.

---

## 2. Lấy SOURCE URL từ Supabase OLD

Supabase → Project OLD → Connect.

Ưu tiên **Session Pooler / port 5432** hoặc Direct PostgreSQL port 5432.

Không dùng URL HTTP/API. Phải là PostgreSQL URI.

Ví dụ:

`postgresql://postgres.PROJECT_REF:PASSWORD@HOST:5432/postgres?sslmode=require`

Project Supabase đang vượt Database Size vẫn có thể được dùng làm nguồn đọc/dump nếu kết nối PostgreSQL còn hoạt động. Trong lúc dump, không thực hiện Import/Save/Batch/Schedule mới.

---

## 3. Chuẩn bị máy Windows

Cần:

- Node.js
- PostgreSQL client tools (`pg_dump`, `pg_restore`)

Kiểm tra:

```bat
node --version
pg_dump --version
pg_restore --version
```

Nếu Windows không nhận `pg_dump`, cài PostgreSQL client hoặc điền đường dẫn vào `.env`:

```text
PG_DUMP_PATH=C:\Program Files\PostgreSQL\17\bin\pg_dump.exe
PG_RESTORE_PATH=C:\Program Files\PostgreSQL\17\bin\pg_restore.exe
```

---

## 4. Giải nén package và tạo `.env`

Copy `.env.example` → `.env`.

Điền:

```text
SOURCE_DB_URL=<PostgreSQL URL Supabase OLD>
TARGET_DB_URL=<Aiven Service URI>
MIGRATION_CONFIRM=SUPABASE_TO_AIVEN_FULL
```

Không đảo SOURCE/TARGET.

---

## 5. RUN_1_PREFLIGHT.cmd

Double-click:

`RUN_1_PREFLIGHT.cmd`

Lần đầu script tự chạy `npm install`.

Preflight kiểm tra:

- SOURCE và TARGET không trùng nhau.
- SOURCE có public tables.
- TARGET Aiven phải là database mới/rỗng.
- PostgreSQL version.
- Database size hai bên.

Kết quả cần thấy:

`PRE-FLIGHT OK`

Nếu TARGET đã có public tables, script dừng để tránh ghi đè.

---

## 6. RUN_2_PREPARE_AIVEN.cmd

Chạy:

`RUN_2_PREPARE_AIVEN.cmd`

Bước này chuẩn bị compatibility cho schema Supabase trên PostgreSQL chuẩn:

- bật `aiven_extras`;
- claim ownership của schema `public` cho `avnadmin`;
- bật `pgcrypto`;
- tạo placeholder roles `anon`, `authenticated`, `service_role` để các RLS policy trong schema Supabase restore được.

Các role này `NOLOGIN`; V438 không dùng chúng làm runtime database user.

Kết quả:

`AIVEN PREPARE OK`

---

## 7. DỪNG GHI dữ liệu tạm thời

Ngay trước dump chính thức:

- không Import Master;
- không Import All Open Jobs;
- không Create/Add/Delete Batch;
- không Save/Edit/Bỏ điều độ;
- không cập nhật Production Execution.

Tốt nhất chỉ một mình bạn thao tác trong khoảng migration.

`pg_dump` là snapshot tại một thời điểm; dữ liệu ghi sau thời điểm snapshot sẽ không tự sang Aiven.

---

## 8. RUN_3_DUMP_SUPABASE.cmd

Chạy:

`RUN_3_DUMP_SUPABASE.cmd`

Script dump:

- toàn bộ `public` schema;
- toàn bộ data trong `public`;
- tables/indexes/functions/triggers/views/RLS policies/constraints;
- **không lọc history**;
- **không giảm md_routing_detailed**;
- **không xóa index cũ**.

File tạo tại:

`artifacts/st-planning-full.dump`

Đây đúng với quyết định: **copy nguyên DB hiện hành trước, giảm sau**.

---

## 9. RUN_4_RESTORE_AIVEN.cmd

Chỉ chạy khi dump thành công.

Double-click:

`RUN_4_RESTORE_AIVEN.cmd`

Script kiểm tra TARGET vẫn rỗng rồi mới restore. Không dùng `--clean`, vì target phải là database mới; cách này tránh vô tình xóa database Aiven đã có dữ liệu.

Sau restore script chạy `ANALYZE` để PostgreSQL có statistics mới cho query planner.

Kết quả:

`AIVEN RESTORE OK`

---

## 10. RUN_5_VERIFY.cmd

Chạy:

`RUN_5_VERIFY.cmd`

Verify thực hiện:

- so danh sách public tables SOURCE ↔ TARGET;
- chạy exact `count(*)` cho từng public table;
- báo table nào thiếu/mismatch;
- hiển thị Database Size SOURCE và Aiven.

Chỉ khi thấy:

`VERIFY OK — table set and row counts match.`

mới được đổi Vercel.

Nếu fail: **không đổi Vercel**.

---

## 11. Deploy source ST Planning V438

V438 thay tầng database sang PostgreSQL chuẩn:

```text
DATABASE_URL=<Aiven Service URI>
DB_POOL_MAX=1
DB_CONNECT_TIMEOUT_MS=20000
```

Trong Vercel → Project → Settings → Environment Variables:

### Thêm/đổi

```text
DATABASE_URL=postgres://avnadmin:.../defaultdb?sslmode=require
DB_POOL_MAX=1
DB_CONNECT_TIMEOUT_MS=20000
```

### Giữ tạm Supabase cho Storage/Auth

```text
NEXT_PUBLIC_SUPABASE_URL=...   # chỉ nếu còn dùng Supabase Storage/import cũ
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...   # chỉ nếu flow cũ cần
```

### Có thể bỏ sau khi deploy V438

```text
SUPABASE_DB_URL
DB_CONNECTION_STRING
```

V438 không còn dùng hai biến DB Supabase cũ.

Redeploy deployment mới.

---

## 12. Smoke test bắt buộc

Test lần lượt:

1. Dashboard.
2. Master Data.
3. Part Tracker.
4. All Open Jobs.
5. Job Tracker.
6. Planning Board.
7. Existing Batch.
8. Create/Add Batch test.
9. Board Điều Độ.
10. Previous Main lock.
11. Chemical Line proposal/FB/Loading/Process/NDT/Unloading.
12. Masking/Unmasking.
13. Báo cáo sản xuất.
14. Save Schedule và Bỏ điều độ.

Sau đó kiểm tra Aiven metrics: connections, CPU, disk.

### Aiven Free connection limit

Bắt đầu `DB_POOL_MAX=1`.

Nếu trang DB bị queue/chậm nhưng Aiven `Connections` luôn thấp, có thể thử `DB_POOL_MAX=2`. Không tăng cao ngay vì Aiven Free có tổng `max_connections=20` và Vercel có thể tạo nhiều runtime instance.

---

## 13. Supabase Storage sau cutover

V438 chỉ chuyển **database** sang Aiven. Import `.xlsx` vẫn dùng Supabase Storage tạm thời.

Nếu project Supabase OLD vẫn đang bị restriction do Database Size >500 MB, phần upload/import qua Storage có thể vẫn bị ảnh hưởng. Sau khi Aiven đã verify và app DB chạy ổn, ta sẽ làm một bước riêng:

- giữ OLD làm backup ngắn hạn;
- giảm/xóa dữ liệu PostgreSQL ở Supabase OLD hoặc chuyển Storage sang provider khác;
- không trộn việc này vào migration database lần đầu.

Không được xóa OLD trước khi Aiven smoke test hoàn tất.

---

## 14. Rollback

Nếu V438 + Aiven có lỗi nghiệp vụ:

1. Không xóa Aiven.
2. Vercel → `DATABASE_URL` đổi tạm về PostgreSQL URI của Supabase OLD.
3. Redeploy.

V438 là provider-neutral nên `DATABASE_URL` có thể trỏ lại PostgreSQL OLD để rollback.

---

## 15. Phase 2 sau khi Aiven chạy ổn

Sau khi bạn xác nhận vận hành ổn, mới giảm DB Aiven:

- audit `md_routing_detailed` inactive;
- audit 202 MB Routing indexes và index overlap;
- dọn `open_job_history`;
- dọn inactive/stale planning rows nếu an toàn;
- giữ đúng index runtime V437/V438;
- VACUUM/REINDEX khi cần.

Mục tiêu Phase 2: giảm ~600 MB xuống vùng an toàn hơn mà **không làm migration và cleanup cùng lúc**.


## V462 — Batch Size theo Recipe
- Batch Prefix / Sequence Start / Padding vẫn cấu hình theo Main Operation.
- Common Batch Size để trống được phép.
- Có thể thêm nhiều dòng Recipe + Batch Size cho cùng Main Operation.
- Ưu tiên: Recipe Batch Size → Common Batch Size → không split nếu cả hai trống.
- Auto Split OFF: luôn tạo một batch cho phần Qty được chọn, bất kể Batch Size.
- Planning Board vẫn gộp nhiều Batch No trong cùng ô bằng dấu `&`; Scheduling/Preparation/Production vẫn tách từng Batch.


## V465 — Direct Production Add Job + Added-Job Audit
- Thêm tab **Điều chỉnh đầu ngày** trong nhóm Vận hành.
- Production day giữ chuẩn 06:00 → 05:59 hôm sau. Production Report không tự sửa Planning/Schedule.
- Quét báo cáo để tạo đề xuất **CARRY_OVER** và **REMOVE_JOB**; **ADD_JOB từ Production được thêm trực tiếp**, không chờ approve.
- Carry Over mặc định sang đầu ngày kế tiếp và bắt buộc Preview trước khi duyệt.
- Preview chạy hai chiều ảnh hưởng cần thiết: **Cross-Main Dependency** (kể cả planner khác) + **Resource Cascade**.
- Chỉ khi planner bấm Duyệt mới commit; schedule cũ được giữ dạng CANCELLED để audit và tạo schedule active mới.
- Production Execution có ô **Extra Job** ngay trên từng Batch; chỉ nhập Job Number rồi bấm Thêm/Enter. Job hợp lệ được thêm trực tiếp vào Batch và hiện ngay dưới dòng Batch với nhãn Job thêm mới.
- Batch Detail có **Add Job nhanh** dùng chung tất cả khu vực: chỉ nhập Job Number, tự lookup Part/Rev/Qty/Surface/Main/Operation/Recipe/Status và validate.
- Tab **Điều chỉnh đầu ngày** không duyệt ADD_JOB nữa; chỉ hiển thị thông báo/audit Batch + Job đã được Production thêm. Validation vẫn chặn Recipe mismatch, Job đang ở Batch active khác hoặc vượt Batch Size cấu hình.
- Migration mới: `078_daily_production_adjustment.sql`, tối đa 4 SQL statements theo giới hạn executor.

- V465 sửa lỗi ô nhập Extra Job mất focus: gõ liên tục không cần click lại sau từng ký tự.


## V467 · Job thêm từ Production truyền chú ý sang Next Main
- Production thêm Job ngoài lô ở Main hiện tại: thêm trực tiếp như V465/V466.
- Hệ thống lấy Next Main theo route thật của Job, không hard-code theo khu vực.
- Batch đích được nhận diện bằng các Job chung giữa Batch nguồn và Batch Next Main; ưu tiên Batch có overlap lớn nhất.
- Scheduling Board hiện Attention/Handover cho Batch đích.
- Production Report của Batch đích hiện Job cần bổ sung và nút **Thêm Job này**.
- Khi bấm, Job vào Batch đích với Production status **WAITING**, không tự hoàn thành.
- Nếu còn Main tiếp theo, attention được truyền tiếp theo cùng cơ chế.
- Không cần migration SQL mới; dùng `planning_handover_change_event` hiện hữu.

## V468 · Cảnh báo thay đổi bởi Sản xuất
Tab `Cảnh báo thay đổi SX` là màn hình read-only dành cho planner để theo dõi tất cả Job được Production thêm ngoài lô. Mỗi alert hiển thị Job/Part/Qty/Surface, Batch/Main/Recipe/Resource/Schedule bị thay đổi, Batch Qty trước/sau, Next Main, Planner/Batch/Resource đích, trạng thái Attention và audit lý do. Job được truyền tiếp từ Previous Main cũng xuất hiện để nhìn xuyên chuỗi. Không approve hoặc chỉnh Batch/Schedule tại tab này.

## V469 — Job thêm bởi Production không mất sau khi reload
Ở Painting/Chemical Line vẫn báo cáo theo dòng Batch. Tuy nhiên hệ thống luôn tải membership Job của Batch để các Job được Production thêm ngoài kế hoạch tiếp tục hiện bên dưới dòng Batch sau khi đổi tab, tạo thêm Batch khác hoặc reload trang. Đây chỉ là dữ liệu hiển thị/audit; không đổi sang báo cáo trạng thái theo từng Job ở các khu vực LINE.

## V470 — Logic & Hướng dẫn mới nhất + Training người mới
- Cập nhật tab **Logic & Hướng dẫn** đến logic V469: Production Add Job trực tiếp, Next Main Attention, Cảnh báo thay đổi SX, Job Production-added tồn tại sau reload, Carry Over/Cross-Main/Resource Cascade và phân biệt READY với dependency thời gian.
- Thêm tab **Training người mới** trong nhóm Quản trị.
- Training theo đúng vòng đời một Job: All Open Jobs → Job Tracker → Planning Board → Board Điều Độ → Production Execution → Điều chỉnh đầu ngày → Cảnh báo thay đổi SX.
- Nội dung Training gồm: 6 nguyên tắc cốt lõi, lộ trình từng màn hình, bài thực hành, tình huống sai/lệch, checklist trước khi thao tác độc lập và câu hỏi tự kiểm tra.
- Không thêm migration SQL và không thay đổi business logic Planning/Scheduling/Production.


## V472 - Training người mới theo lý thuyết → thực hành
Tab Training được mở rộng từ khái niệm chung nhất đến chi tiết: Operation Code → ST Scope/ST Group → Main Operation/Main Planning Order → Area/Planner → Recipe/Batch Key/Batch Size/Time Rules → Planning → Batch → Scheduling → Production. Có ví dụ mô phỏng một Job xuyên suốt và thư viện tình huống vận hành/ngoại lệ. Không thay đổi business logic hoặc database.


## V473 — Area Display Order + Preparation split + READY previous DONE
- Configuration có tab **Area Display Order** dùng `md_area.sort_order` làm nguồn thứ tự hiển thị theo Physical Area; không đổi mapping hay business flow.
- Production Report > Masking & Unmasking tách riêng panel theo **Area + Main**: PRIMER, PRIMER2, PRIMER3, TOPCOAT1, TOPCOAT2, ANTI-ABRASION.
- READY split dùng cùng logic trên Planning Board/Dashboard/Scheduling: Previous Main đã **Scheduled hoặc DONE by physical progress** (kể cả không có Batch) thuộc `READY_PREV_SCHEDULED`; plan-ahead chưa handoff thuộc `READY_PREV_UNSCHEDULED`. **V476 cập nhật thêm: Main đầu tiên của chain cũng thuộc `READY_PREV_SCHEDULED` vì không có predecessor phải chờ.**
- Logic & Hướng dẫn và Training được cập nhật song song.

## V474 — Training bằng dữ liệu thật
Tab Training đọc live database để minh họa Operation Code → ST Group → Main → Area/Planner → Recipe → Batch Rules → Process Time → Batch → Schedule trên dữ liệu đang dùng. Có ô nhập Job Number để trace một Job thật. Training và Logic & Hướng dẫn phải được cập nhật song song khi có logic mới.

## V475 — READY Workload drill-down đồng bộ với V473
Khi click `READY · Previous Main Scheduled / Done` trên Planning Board, danh sách Job bên dưới phải dùng đúng cùng classifier với Workload Summary. Ngoài Previous Main có Schedule thật, Job đang ở current READY Main cũng thuộc cột này khi Previous Main đã đi qua theo physical progress/DONE dù lịch sử cũ không có Batch/Schedule. V475 sửa phần drill-down để không còn trường hợp KPI có Job nhưng bảng Candidate trống.


## V476 - READY First Main classification
- Main Planning đầu tiên trong chuỗi, khi đã READY/ELIGIBLE, được tính vào `READY · Previous Main Scheduled / Done`.
- Không còn tính First Main vào `READY · Previous Main Unscheduled / START`.
- Workload Summary và drill-down Planning Board dùng cùng classifier.
- Không thay đổi Sequential READY/WAIT, Batch, Recipe, Scheduling hay Production.

---

# V478 — Đăng nhập và phân quyền đầy đủ trên Aiven

Từ V478, ST Planning bắt buộc đăng nhập trước khi vào hệ thống bằng account lưu trên Aiven PostgreSQL. Sau khi đăng nhập, menu và dữ liệu thao tác được giới hạn theo `Role + Permission + Scope`; backend API cũng kiểm tra lại nên việc ẩn nút không phải lớp bảo mật duy nhất.

Vai trò mặc định: `ADMIN`, `PLANNER`, `PRODUCTION_OPERATOR`, `SHIFT_SUPERVISOR`. Admin có tab **Quản trị → Users & Permissions** để tạo account bằng email/mật khẩu tạm, khóa/mở account, gán nhiều Role, chỉnh từng Permission và giới hạn `PLANNING_MAIN`, `SCHEDULE_AREA`, `PRODUCTION_AREA`.

Production được tách quyền: Operator có `production.report`; Shift Supervisor có thêm `production.add_job`. Vì vậy Operator báo cáo trạng thái/Actual/Note nhưng không thấy chức năng thêm Job ngoài lô. Shift Supervisor mới có quyền Production Add Job và nhận Job từ Next Main Attention.

## Triển khai V478
1. Chạy `079_rbac_core.sql`.
2. Chạy `080_rbac_permissions_scope.sql`.
3. Chạy `081_rbac_seed_roles_permissions.sql`.
4. Chạy `082_rbac_indexes.sql`.
5. Chạy thêm `083_aiven_app_auth_credentials.sql` và `084_aiven_app_sessions.sql` trên Aiven.
6. Trong Vercel/`.env`, đặt `ADMIN_EMAILS=<email admin đầu tiên>` và `BOOTSTRAP_ADMIN_PASSWORD=<mật khẩu bootstrap mạnh>`. Có thể đặt `SESSION_HOURS=12`.
7. Deploy, đăng nhập bằng email bootstrap Admin + mật khẩu bootstrap, sau đó vào **Users & Permissions** để tạo account thật và gán quyền/scope. Login/RBAC không cần `SUPABASE_SECRET_KEY`.

Mỗi migration V478 có tối đa 4 câu SQL. Chi tiết kiến trúc xem `V478_FIX.md`, tab **Logic & Hướng dẫn**, và chương phân quyền trong **Training người mới**.

## V483 — Audit VI/EN triệt để

V483 chuẩn hóa toàn bộ catalog song ngữ và thêm quality gate cho các thay đổi UI sau này. Nguồn UI ưu tiên EN, catalog chịu trách nhiệm render VI. Các thuật ngữ nghiệp vụ chuẩn như Job, Batch, Recipe, Main Operation, Operation Code, ST Group, Planning Board, Resource, Planner, READY/WAIT/DONE vẫn được giữ để người vận hành đối chiếu đúng với hệ thống. Các từ tiếng Anh thông thường trong câu tiếng Việt như compatibility, rule, condition, dependency, flow, issue, runtime, handoff, reload, database, Duration/Start Time đã được chuẩn hóa khi phù hợp.

Sau khi chỉnh text UI, luôn chạy `npm run i18n:check`. V483 yêu cầu không có conflict EN→VI, không có conflict VI→EN và không cho các grammar fragment nguy hiểm chạy ở phrase-mode.


## V484 · Production Add Job gọn + Attention toàn bộ downstream Main

- Nút **Add Job** đặt cạnh **Batch No.** trên Production Execution. Chỉ khi bấm mới mở ô nhập Job No.; **Save** để thêm, **Cancel** để đóng.
- Production Add Job vẫn thêm trực tiếp vào Batch nếu validation hợp lệ và không cần Daily Production Adjustment approve.
- Sau khi thêm, hệ thống đọc **Planning Chain thật của Job** và tạo `PRODUCTION_ADD` handover event cho **tất cả Main Planning có planning_seq lớn hơn Main hiện tại**, không chỉ Main kế tiếp đầu tiên.
- Với mỗi downstream Main, hệ thống dùng overlap các Job của Batch nguồn để suy Batch đích phù hợp. Nếu chưa có Batch đích, event vẫn tồn tại để planner theo dõi.
- Production Attention hiển thị rõ **Job · Source Batch · Source Main → Downstream Main · Recipe No. · Recipe Name**. Ví dụ: `F0200884 · CHM00001 · CPBILP → BSAUNSLD · Recipe 002 · Anodizing BSA Unsealed`.
- Khi nhận Job từ Attention, Job downstream ở trạng thái **WAITING**; không tự DONE. Duplicate NEW attention được chặn theo Source Batch + Job + Downstream Main + Target Batch.
- Không thay đổi Recipe rule, Batch Size, Planning READY/WAIT, Scheduling dependency hay Production status logic khác.


## V485 · Daily Adjustment Scan = latest snapshot
- `Quét báo cáo trước 05:59` đối soát lại trạng thái Production hiện tại, không cộng dồn cảnh báo cũ.
- Carry Over / Remove Job còn `PENDING` nhưng Batch/Job đã `DONE` (hoặc không còn thỏa điều kiện) sẽ tự biến mất sau lần quét tiếp theo.
- `APPROVED` / `REJECTED` và audit `ADD_JOB` không bị xóa.
- Không thay đổi Batch, Recipe, Scheduling cascade hay Production reporting.


## V486 — Dashboard READY split giống Planning Board

- `ST Workload Summary · By Area` trên Dashboard tách `READY` thành hai cột: `READY · Previous Main Scheduled` và `READY · Previous Main Unscheduled / START`.
- Classifier dùng cùng logic Planning Board: Previous Main có Schedule hoặc đã DONE theo physical progress → Scheduled; Main đầu tiên của chain cũng → Scheduled; plan-ahead chưa handoff → Unscheduled / START.
- Hai cột READY cộng lại đúng READY tổng. WAIT / PLANNED-UNSCHEDULED / SCHEDULED / HOLD / ST ONLY không đổi.


## V487 — Future ST Job + Auto Preparation khi Production Add Job

- Production Add Job áp dụng cho mọi Main Planning, không hard-code CPBILP/BSA/Primer.
- Nếu Job có trong All Open Job nhưng RAW NextOperation vẫn ở bộ phận khác, server tự sync riêng Job từ AllOperation. Target Main chỉ được chấp nhận khi tồn tại trong current/future ST routing thật.
- Nếu Production đưa Job vào một Main phía sau trong khi còn Main ST trước đó chưa có Batch, các Main chưa thực hiện trước Target được đưa khỏi live chain. Marker Production entry được lưu trong audit ADD_JOB và được Planning Chain dùng để không dựng lại các Main cũ cho tới khi RAW position bắt kịp. RAW NextOperation không bị sửa.
- Sau khi Add/Accept Job vào Batch, resolver Masking/Unmasking hiện tại được chạy lại. Nếu Main có Preparation, Job được tạo trực tiếp trong Production Report ở trạng thái WAITING. Không kế thừa DONE từ Job cũ.
- Có hay không có Masking/Unmasking không ảnh hưởng propagation: hệ thống vẫn tạo Attention cho tất cả Main Planning phía sau theo route thật.
- Production page refresh server state sau Add/Accept để Preparation mới xuất hiện ngay.
- Không có SQL migration mới.


## V488 — Production Add Job giữ danh sách cộng dồn

- `Jobs added during production` là danh sách cộng dồn theo **Batch + Job**, không phải chỉ Job thêm gần nhất.
- Thêm Job B/C không được làm mất Job A đã thêm trước nếu A vẫn còn membership trong Batch.
- Cờ Production-added đọc audit `ADD_JOB APPROVED` theo Batch + Job để không phụ thuộc vào occurrence id có thể thay đổi khi Future ST được reconciliation.
- Refresh sau Add Job vẫn phải giữ đủ các Job Production-added đang thuộc Batch.
- Logic & Guide và Training đã cập nhật đồng bộ. Không có SQL migration mới.


## V489 — Tách WAIT thành Next Main và Future Mains

- Không đổi schema và không đổi trạng thái nội bộ: các Main chưa tới lượt vẫn lưu `planning_job_operation.status = LOCKED`.
- `WAIT · Next Main` = occurrence LOCKED gần nhất của Job theo Planning Chain hiện tại.
- `WAIT · Future Mains` = toàn bộ occurrence LOCKED còn lại phía sau.
- Hai nhóm cộng lại đúng `WAIT` tổng; khi frontier dịch chuyển sau handoff/Create Batch, classifier tự tính lại.
- Route Matrix hiển thị compact `W1` cho Next Main và `W2` cho Future Mains.
- Planning Board Workload Summary, Dashboard `ST Workload Summary · By Area` và Scheduling Workload Summary dùng cùng phân loại.
- READY split V486 giữ nguyên; Batch, Recipe, Scheduling dependency và Production logic không đổi.
- Logic & Guide và Training được cập nhật đồng bộ. Không có SQL migration mới.

## V490 — Scheduling Board Workload: READY-first + Flybar Recipe-only + WAIT Next breakdown

- `ST Workload Summary · By Area` trên Scheduling Board đổi thứ tự cột: `Main Operation → Recipe No → Recipe Name → READY Previous Main Scheduled/Done → READY Previous Main Not Yet Scheduled → WAIT Next Main → WAIT Future Mains → PLANNED-UNSCHEDULED → SCHEDULED → HOLD → Total`.
- READY Scheduled/Done dùng xanh lá đậm; READY Not Yet Scheduled dùng xanh lá nhạt.
- Chemical Line/Flybar chỉ hiển thị Recipe rows, bỏ MAIN TOTAL để gọn; Main Operation vẫn lặp ở từng Recipe row.
- Ngoài Chemical Line, `WAIT · Next Main` breakdown theo immediate Previous Main Planning của từng Job để planner biết workload đang chờ từ Main nào.
- Không đổi classifier V489: `LOCKED` gần nhất = WAIT Next Main, các LOCKED phía sau = WAIT Future Mains.
- Không đổi rule mở Next Main: Previous Main chỉ cần có Plan/Batch là mở đúng một Next Main READY; Schedule chỉ phân loại READY, không phải điều kiện mở.
- Logic & Guide và Training cập nhật đồng bộ. Không có SQL migration mới.

## V491 — Scheduling Workload gọn hơn + READY card xanh + WAIT breakdown đầy đủ

- `ST Workload Summary · By Area` trên Scheduling Board chỉ giữ: `Main Operation → Recipe No → Recipe Name → READY Scheduled/Done → READY Not Yet Scheduled → WAIT Next Main → WAIT Future Mains → HOLD`.
- Riêng bảng workload ở tab Điều độ, các cột `PLANNED-UNSCHEDULED`, `SCHEDULED` và `Total` được ẩn để giảm chiều ngang; dữ liệu Schedule thật không bị xóa và logic điều độ không đổi.
- Hai cột READY dùng cùng kiểu card phẳng như `WAIT · Next Main`: Scheduled/Done xanh lá đậm hơn, Not Yet Scheduled xanh lá nhạt hơn; bỏ kiểu header xanh quá đậm và border trái.
- `WAIT · Next Main` breakdown hiển thị đầy đủ `← Previous Main · Job · pcs · dm²`.
- Chemical Line/Flybar vẫn chỉ hiển thị Recipe rows nhưng từ V491 cũng có WAIT Next Main breakdown.
- Rule mở Next Main không đổi: Previous Main chỉ cần đã Plan/tạo Batch là mở đúng một Next Main READY; Schedule chỉ dùng để phân loại READY Scheduled/Done hay Not Yet Scheduled.
- Logic & Guide và Training được cập nhật song song. Không có SQL migration mới.

## V492 — Scheduling Workload → Planning Board Quick View

- Click trực tiếp card trong `ST Workload Summary · By Area` để mở popup Planning Board lọc đúng `Area + Main Operation + Recipe + workload bucket`; click breakdown `WAIT · Next Main` còn lọc thêm `Previous Main`.
- Popup hiển thị Job, Part/Rev, Description, Qty, dm², Priority, Previous Main, Main hiện tại, Recipe hiện tại và thêm các cột `Next Main`, `Next Recipe No`, `Next Recipe Name`.
- Chỉ `READY · Previous Main Scheduled / Done` và `READY · Previous Main Not Yet Scheduled` được chọn Job để `Add to Batch` hoặc `Create New Batch`.
- `WAIT · Next Main`, `WAIT · Future Mains`, `HOLD` chỉ xem, không cho bypass gating.
- Tạo/thêm Batch gọi lại canonical `/api/planning/batch`, vì vậy recipe compatibility, batch size/auto split, permission/scope và rule mở đúng một Next Main vẫn giữ nguyên.
- Sau mutation, popup và Scheduling Workload refresh lại từ server.
- Logic & Guide và Training được cập nhật song song. Không có SQL migration mới.


## V493 · Planning Board Quick View column filters
- Scheduling Board → ST Workload Summary → Planning Board Quick View có nút filter trên từng cột dữ liệu.
- Hỗ trợ lọc đồng thời nhiều cột: Job, Part/Rev, Description, Qty, dm², Priority, Previous Main, Main, Recipe No/Name, Next Main, Next Recipe No/Name, Batch.
- Check-all chỉ chọn các dòng đang hiển thị sau lọc; selection thủ công và canonical Batch API giữ nguyên.
- Clear filters trả popup về toàn bộ Job của card. Không đổi READY/WAIT/HOLD hay Batch/Scheduling logic.

## V494 — Recent Batches: xuất Excel từng Batch

- Thêm nút `Xuất Excel` cạnh `Delete` ở từng dòng `Planning Board → Recent Batches`.
- File lấy trực tiếp Job membership từ `planning_batch_job`, không phụ thuộc state UI.
- Cột xuất theo mẫu Planning Matrix: `Job`, `Part / Rev`, `Qty`, `Surface`, `Operation Code`, `Previous Operation`, `Next Main Operation`, `Recipe`, `Primer 1`, `Primer 2`, `Primer 3`, `Priority`, `Status`, `Batches`.
- Qty/Surface là allocation thật trong Batch; Recipe ưu tiên Recipe của Batch; Next Main đọc Planning Chain active kế tiếp.
- Export là read-only, có kiểm tra `planning.view` + scope Main; không đổi READY/WAIT, Batch, Schedule hay Production. Không có SQL migration mới.


## V495 — Internal Chat + thông báo Cross-Planner

- Thêm tab `Internal Chat` dùng chung cho team ST Planning; tin nhắn và trạng thái đã đọc lưu trên Aiven PostgreSQL.
- ADMIN, PLANNER, PRODUCTION_OPERATOR và SHIFT_SUPERVISOR mặc định có `chat.view` + `chat.send` sau migration 085.
- Menu Chat hiển thị badge số tin chưa đọc; trang Chat tự refresh định kỳ.
- Sau khi thay đổi nghiệp vụ đã commit, hệ thống gửi thêm SYSTEM message vào Chat cho các thay đổi chính của Planning, Scheduling, Production và Daily Production Adjustment. Chat lỗi không được rollback transaction nghiệp vụ đã lưu.
- Nếu Main nguồn thuộc Planner 1 nhưng downstream Main bị ảnh hưởng thuộc Planner 2, message được gắn `CROSS-PLANNER: Planner 1 → Planner 2`; chiều ngược lại dùng cùng resolver động `Main → Schedule Area → Planner Assignment`, không hard-code tên Main.
- Production Change Alerts, handover attention, Daily Production Adjustment và audit hiện tại vẫn giữ nguyên; Chat chỉ là lớp trao đổi/thông báo bổ sung, không duyệt hoặc sửa Planning/Schedule trực tiếp.
- SQL triển khai: `V495_APPLY_AIVEN.sql` — đúng 4 executable statements.
- Logic & Guide và Training được cập nhật song song.

---

## V496 · Dashboard Workload Alignment + Scheduling READY Recipe Breakdown

- Dashboard bỏ toàn bộ KPI card; workload chi tiết đọc trực tiếp từ `ST Workload Summary · By Area`.
- Dashboard sắp xếp cột và dùng màu bucket giống Planning Board: WAIT Next → WAIT Future → READY Scheduled → READY Unscheduled/START → PLANNED-UNSCHEDULED → SCHEDULED → HOLD → ST ONLY → Total.
- Scheduling Board: ở từng Recipe row, hai cột READY có breakdown theo Recipe của Previous Main (`Previous Main · Previous Recipe No · Job · pcs · dm²`). MAIN TOTAL không breakdown.
- First Main/START không có previous-recipe breakdown.
- Không thay đổi logic mở Next Main: Previous Main chỉ cần đã Plan/Batch là đủ mở đúng một Next Main; Schedule chỉ phân loại READY Scheduled/Done hay Not Yet Scheduled.
- Không có SQL migration mới.
