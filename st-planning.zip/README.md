# v313 — NO_CHAIN rescue: NextOperation Main = Current Main

- Nền code: v312.
- Giữ nguyên resolver hiện tại; chỉ bổ sung fallback cuối trước khi kết luận `NO CHAIN`.
- Nếu kết quả chuẩn vẫn là `NO_CHAIN` nhưng `NextOperation` chính là một Main Planning occurrence hợp lệ của Job, **Main đó là Current Main**.
- Nếu `NextOperation` xuất hiện lặp lại trong `AllOperation`, chỉ dùng `LastLaborOp` để định vị occurrence; nếu vẫn còn nhiều occurrence thì không đoán.
- Sau khi Current Main được xác định, **Next Main Planning = các Main tiếp theo trong chính `AllOperation` của Job** sau chuẩn hóa Mapping + Planning Scope.
- Nếu `LastLaborOp` rỗng/stale nhưng `NextOperation` là một Main Planning occurrence duy nhất, vẫn lấy `NextOperation` làm Current Main.
- Current Main và toàn bộ Next Main(s) tiếp tục theo logic v312: chưa có Batch = `READY`, có Batch = `PLANNED`; Schedule chỉ hiển thị trạng thái thực tế, không gate plan-ahead.
- Không thay Recipe, Batch Key, Auto/Manual Bridge discovery, Schedule engine.
- Không có migration SQL mới. Sau deploy bấm **Rebuild Chain** một lần.

Xem chi tiết: `docs/PLANNING_NEXTOP_MAIN_NO_CHAIN_RESCUE_V313.md`.

# v312 — Plan-ahead: Current + all Next Main READY

- Nền code: v311.
- Vị trí Job vẫn giữ nguyên resolver: `MANUAL Segment → AUTO Segment → AllOperation fallback → NO CHAIN`, chỉ dùng `LastLaborOp + NextOperation` để định vị.
- Sau khi xác định Current Main, **Current Main và tất cả Next Main phía sau đều `ELIGIBLE` / UI `READY` mặc định** nếu chưa có Batch.
- Không còn `LOCKED / WAIT PREV` vì Main trước chưa Schedule; hỗ trợ tạo Batch plan-ahead cho nhiều Main phía sau.
- Main có Batch active vẫn giữ `PLANNED`; Route Matrix ưu tiên hiển thị trạng thái Schedule thực tế `SCHEDULED / RUNNING / HOLD / COMPLETED`.
- Main phía trước Current giữ lịch sử thực tế: có Schedule → trạng thái Schedule; có Batch chưa Schedule → `PLANNED-UNSCHEDULED`; không có history → `DONE` theo progress.
- Đã loại bỏ helper Schedule-handoff cũ; Scheduling không còn mở khóa Main kế tiếp.
- Không đổi Recipe, Batch Key, Auto/Manual Bridge discovery hay Scheduling engine.
- Không có migration mới. Sau deploy bấm **Rebuild Chain** một lần.

Xem chi tiết: `docs/PLANNING_PLAN_AHEAD_ALL_READY_V312.md`.

# v311 — AllOperation first-Main fallback fix

- Nền code: v310.
- Resolver giữ nguyên thứ tự: `MANUAL Segment → AUTO Segment → AllOperation fallback → NO CHAIN`.
- Khi không Segment nào match và cả `LastLaborOp` lẫn `NextOperation` đều không xuất hiện trong `AllOperation`, nhưng canonical route vẫn có Main Planning, hệ thống lấy **Main Planning đầu tiên** làm `Current Main`.
- Main đầu tiên này có `requiredPreviousInstanceKey = null`, nên nếu chưa có Batch history thì trạng thái là `ELIGIBLE` / UI hiển thị `READY`.
- Ví dụ `AllOperation = CPBILP-A | PIONBL | TSAUNSLD | PPRSLVT | ...`, `LastLaborOp=INSMA`, `NextOperation=MSKG-PC` → `Current Main = CPBILP-A`, `READY`.
- Chỉ trả `NO CHAIN` khi Segment không match và AllOperation/canonical route không còn xác định được Main Planning hợp lệ.
- Schedule/Batch history vẫn không dùng để định vị Current Main.
- Không có migration mới. Sau deploy bấm **Rebuild Chain** một lần.

Xem chi tiết: `docs/PLANNING_ALLOPERATION_FIRST_MAIN_FALLBACK_V311.md`.

# v310 — Segment → AllOperation nearest-Main fallback → NO CHAIN

- Nền code: v309.
- Vị trí Job vẫn chỉ dùng `LastLaborOp + NextOperation` từ All Open Job.
- Thứ tự resolver mới: `MANUAL Segment → AUTO Segment → AllOperation fallback → NO CHAIN`.
- Chỉ khi **không Segment nào match**, hệ thống mới xem `AllOperation` của chính Job.
- AllOperation fallback lấy **Main Planning upcoming gần nhất** từ vị trí pair; hỗ trợ trường hợp một Intermediate không tồn tại trong AllOperation bằng occurrence duy nhất của thành viên còn lại trong pair.
- Nếu nhiều occurrence dẫn tới nhiều Current Main khác nhau hoặc không còn Main hợp lệ → `NO CHAIN`, không tự đoán.
- Schedule/Batch history chỉ tính `ELIGIBLE / LOCKED / PLANNED / SCHEDULED`, không dùng để định vị Current Main.
- Không có migration mới. Sau deploy bấm **Rebuild Chain** một lần.

Xem chi tiết: `docs/PLANNING_ALLOPERATION_NEAREST_MAIN_FALLBACK_V310.md`.

# v309 — Manual Intermediate Bridge Segments

- Nền code: v308.
- Thêm `MANUAL` Intermediate Bridge Segment dùng chung model với `AUTO_ROUTING`.
- UI ST Operation Flow có form Manual: Previous Main → ordered Intermediate Operations → Next Main, Priority, Note.
- Có Sửa / Ngưng Manual Segment; filter `Tất cả / AUTO / MANUAL`.
- Resolver vẫn chỉ dùng `LastLaborOp + NextOperation` để định vị physical position.
- Thứ tự rule: `MANUAL > AUTO_ROUTING`; nếu nhiều MANUAL cùng match thì priority lớn hơn thắng.
- Schedule history chỉ tính READY/WAIT/PLANNED/SCHEDULED, không dùng để chọn Segment.
- Full/Incremental Auto Bridge rebuild chỉ thay `AUTO_ROUTING`; Manual không bị xóa hoặc overwrite.
- Sau thay đổi Manual cần `Rebuild Chain` để áp dụng cho Candidate hiện tại.

## Migration bắt buộc

`supabase/migrations/056_manual_intermediate_bridge_segments.sql`

Sau deploy:
1. Chạy migration 056.
2. Vào **Cấu hình → ST Operation Flow → Intermediate Bridge Segments · AUTO + MANUAL**.
3. Tạo Manual Segment nếu cần ngoại lệ.
4. Vào Planning Board bấm **Rebuild Chain** một lần sau khi thay đổi Manual.

# v307 — Auto Bridge Same-Main Occurrence Finalize Fix

- Nền code: v306.
- Sửa lỗi Finalize: `md_intermediate_bridge_segment_prev_next_check` chặn Segment hợp lệ khi cùng một Main Planning xuất hiện lặp lại ở hai occurrence khác nhau.
- Cho phép `Previous Main = Next Main` **theo tên** nếu route evidence có `previous_main_seq < next_main_seq`.
- Finalize v307 kiểm tra staging trước khi publish:
  - Previous/Next Main không được rỗng.
  - `previous_main_seq < next_main_seq`.
- Không cần chạy lại 2.833 routing đã xử lý nếu staging/run hiện tại vẫn còn; sau khi chạy migration 055 có thể bấm `Finalize Bridge` lại.
- Không đổi discovery, chunk/resume/staging, Planning Chain, Recipe, Batch hay Schedule.

## Migration bắt buộc

`supabase/migrations/055_intermediate_bridge_same_main_occurrence.sql`

Sau deploy:
1. Chạy migration 055.
2. Mở lại ST Operation Flow.
3. Với run đã 100%, bấm `Finalize Bridge`.
4. Sau khi publish thành công, nếu Bridge thay đổi thì vào Planning Board bấm `Rebuild Chain` một lần.

# v306 — Auto Bridge 100% Finalize / Resume Fix

- Nền code: v305.
- Sửa trường hợp Full Rebuild đã `processed_routings = total_routings` nhưng run đứng ở `READY_TO_FINALIZE`/`FAILED` và không publish được Bridge ACTIVE.
- Finalize không còn phụ thuộc cứng vào status UI cũ; DB kiểm tra trực tiếp `md_intermediate_bridge_rebuild_route.processed_at`.
- Nếu `remaining_rows = 0`, Finalize được retry an toàn và chuyển run sang `FINALIZING`, kể cả lần Finalize trước đã làm run thành `FAILED`.
- Nếu vẫn còn route chưa xử lý, API trả đúng số `remaining` và đồng bộ lại `processed_routings`.
- Client refresh lại run thật từ API sau lỗi để không giữ state `READY_TO_FINALIZE` cũ khi DB đã đổi trạng thái.
- Khi đã 100%, nút đổi thành `✓ Finalize Bridge`. Không cần chạy lại 2.833 routing hiện có.
- Không có migration mới; giữ migration 053.

# v305 — Auto Bridge quét toàn bộ ST Routing Chain Standardized

- Nền code: v304 của người dùng.
- Sửa gốc phạm vi Full Rebuild: không còn giới hạn `md_st_routing_summary.is_active=true`.
- Full Rebuild lấy **mọi `routing_code` có row `md_st_routing.is_active=true`** trong `ST Routing Chain · Standardized`.
- Lý do: `md_st_routing_summary.is_active` chỉ phản ánh route hiện đang được Part/Revision active sử dụng; các routing pattern Standardized khác vẫn là nguồn hợp lệ để suy ra Intermediate Bridge Segment.
- Mỗi chunk vẫn 150 routing/request, có Resume + Staging + Atomic Finalize nên số route lớn không gây timeout một request.
- Trong từng routing: sort `seq`; Main nhận từ cấu hình Planning + live Mapping; mọi `operation_code` không phải Main nằm giữa 2 Main liên tiếp là Intermediate; `PIONBL`/alias PIONBL bị skip.
- Không có migration mới. Giữ migration `053_intermediate_bridge_chunked_rebuild.sql`.
- Sau deploy phải chạy **Full Rebuild Auto Bridge Segments** mới để snapshot lại toàn bộ routing_code Standardized.

# v302 — Fix Auto Bridge chỉ còn 1 Segment

- Full Rebuild 259/259 routing đã chạy đúng; lỗi nằm ở phân loại Main/Intermediate.
- Main occurrence bây giờ được xác định duy nhất bằng: `operation_code → deterministic live mapping → standard_operation ∈ md_planning_operation_scope`.
- Không dùng `md_st_routing.standard_operation` làm source of truth.
- Không thêm gate phụ `md_st_operation_scope.operation_type` vào việc nhận Main của Auto Bridge.
- Mọi raw operation không phải Main và nằm giữa hai Main liên tiếp được giữ trong ordered Intermediate signature theo `seq`.
- `ST_SCOPE_ONLY` vẫn không trở thành Planning Main/Batch; nếu nằm vật lý giữa hai Main, nó chỉ được dùng như bridge marker để định vị đoạn route.
- `PIONBL` và raw alias map về Main `PIONBL` bị skip khỏi Intermediate signature.
- Chunk/Resume/Staging/Atomic Finalize của v298-v301 giữ nguyên.
- Không có migration mới. Sau deploy cần Full `Rebuild Auto Bridge Segments` lại một lần.

# v300 — Fix Auto Bridge chỉ tạo 1 Segment

- Xác nhận Full Rebuild đã xử lý đủ 259/259 routing; chunk 150 + 109 hoạt động đúng.
- Lỗi nằm ở Auto Discover: v299 dùng `md_st_routing.standard_operation` đã materialize/stale để nhận Main Planning.
- v300 chỉ dùng `md_st_routing` làm nguồn `routing_code + seq + operation_code`; Main được standardize lại từ Mapping live + Planning Scope bằng cùng priority/rule với Planning Chain.
- Hỗ trợ PRIMER/PRIMER2/PRIMER3, TOPCOAT1/TOPCOAT2, HE-BAKE sequence và DIRECT mapping.
- Không thay thuật toán Segment: Previous Main + ordered Intermediate Operations + Next Main; PIONBL/ST_SCOPE_ONLY vẫn loại.
- Không có migration mới. Sau deploy, chạy Full `Rebuild Auto Bridge Segments` lại.

# v299 — Fix Auto Bridge Rebuild RUNNING/integer parameter order

- Sửa lỗi Start Rebuild: PostgreSQL `invalid input syntax for type integer: "RUNNING"`.
- Nguyên nhân: tham số `status` và `total_routings` bị truyền đảo thứ tự trong `startIntermediateBridgeRebuild()`.
- Giữ nguyên toàn bộ kiến trúc v298: chunked + resumable + staging + atomic finalize + incremental.
- Không có migration mới. Nếu đã chạy `053_intermediate_bridge_chunked_rebuild.sql` thì không cần chạy SQL thêm.

# v298 — Chunked / resumable Auto Bridge rebuild

- `Rebuild Auto Bridge Segments` chạy 150 routing/request, có progress + Resume + Cancel.
- Staging theo `run_id`; Planning Board tiếp tục dùng Bridge ACTIVE cũ đến khi Finalize atomically.
- Master Import tạo Incremental Bridge run chỉ cho routing signature thay đổi.
- Migration mới: `053_intermediate_bridge_chunked_rebuild.sql`.

# v297 — Fully Auto Intermediate Bridge Segments

Bản này kế thừa toàn bộ logic đến v296 và thay cơ chế INTERMEDIATE cấu hình tay bằng AUTO inference.

## Logic chuẩn

Planner chỉ cấu hình:

- `PLANNING_OPERATION` (Source → Main Planning + Area/Schedule/Planner),
- `ST_SCOPE_ONLY`.

Không còn chọn `INTERMEDIATE` bằng tay.

Hệ thống dựng **ST Routing Chain · Standardized** từ toàn bộ raw operation nằm trong khoảng từ Main Planning đầu tiên đến Main Planning cuối cùng của từng Part/Revision. Sau đó, theo từng `routing_code` và `seq`:

1. Xác định các row Main Planning từ `standard_operation` + `md_planning_operation_scope`.
2. Lấy từng cặp Main Planning liên tiếp.
3. Mọi `operation_code` nằm giữa hai Main được suy ra là Intermediate.
4. Loại `PIONBL` và `ST_SCOPE_ONLY` khỏi Intermediate sequence.
5. Tạo Bridge Variant theo `Previous Main + ordered Intermediate Operations + Next Main`.
6. Giữ nguyên operation lặp lại; một operation có thể thuộc nhiều Segment.

## UI

Trong **Cấu hình → ST Operation Flow**:

- Auto Intermediate hiển thị read-only.
- Không có option `INTERMEDIATE` trong form.
- Có nút **Rebuild Auto Bridge Segments**.

## Database

Chạy migration:

`052_auto_intermediate_from_main_routing.sql`

Sau deploy, bấm **Rebuild Auto Bridge Segments** một lần.

Batch/Schedule history không bị xóa.


## v303 - Auto Bridge canonical Planning Source fix
- Auto Bridge chỉ coi một `operation_code` là Main khi chính Source Operation đó đang active trong `md_st_operation_scope` với `operation_type=PLANNING_OPERATION`, sau đó dùng deterministic live mapping và kiểm tra `md_planning_operation_scope`.
- Mọi raw `operation_code` khác nằm giữa hai Main liên tiếp trong cùng `routing_code`, theo `seq`, được suy ra là Intermediate.
- Không dùng helper/stale mapping của Intermediate để nâng Intermediate thành Main.
- `PIONBL` và alias map về `PIONBL` vẫn skip.
- Progress mỗi chunk hiện thêm số Main occurrence, số route có >=2 Main, số segment tìm thấy và số Planning source mapping để chẩn đoán trực tiếp.
- Không có migration mới so với v302/v301; giữ nguyên migration 053 cho chunk/resume/staging.

## v308 — Current Main theo LastLaborOp + NextOperation

Planning Chain/Candidate định vị vị trí Job chỉ bằng cặp `LastLaborOp + NextOperation` từ All Open Job. Cặp này được match trực tiếp trong `AllOperation` hoặc trong Auto Intermediate Bridge ACTIVE. Không còn fallback dùng một field đơn lẻ hay Schedule history để đoán Current Main. Candidate lấy row đầu của live chain làm Current Main; các Main phía sau vẫn chọn được trong Route Matrix để tạo Batch. Không cần migration mới.
