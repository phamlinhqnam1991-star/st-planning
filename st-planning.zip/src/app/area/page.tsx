import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AreaManager } from "@/components/area-manager";
export const dynamic="force-dynamic";
export default async function AreaPage(){const s=await createClient();const {data:{user}}=await s.auth.getUser();if(!user)redirect("/login");return <AreaManager/>}
