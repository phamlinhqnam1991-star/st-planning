import {NextRequest,NextResponse} from "next/server";
import {getPool} from "@/lib/db";
import {requireApiUser} from "@/lib/api-auth";
import {resolvePlanningView} from "@/lib/planning/planning-view-server";
import {loadPlanningCandidates} from "@/lib/planning/candidate-data";

// v298: Loading ALL Candidates in one query can exceed the default serverless
// timeout on large boards. Give the route the same headroom as other heavy
// Planning endpoints (still capped by the Vercel plan limit).
export const maxDuration=60;

export async function GET(req:NextRequest){
 const denied=await requireApiUser();
 if(denied)return denied;
 const sp=req.nextUrl.searchParams;
 const areaId=(sp.get("area")||"").trim();
 const op=(sp.get("op")||"").trim();
 const recipeKey=(sp.get("recipe")||"").trim();
 const previousBatchNo=(sp.get("prevBatch")||"").trim();
 // v298: pageSize=all (default) loads every Candidate in ONE response and skips
 // the heavy filtered COUNT query — pagination is removed from Planning Board.
 // Numeric page sizes stay supported for backward compatibility / debugging.
 const rawPageSize=(sp.get("pageSize")||"all").trim().toLowerCase();
 const loadAll=rawPageSize!=="0"&&(rawPageSize==="all"||rawPageSize==="");
 const numericPageSize=Math.trunc(Number(rawPageSize)||200);
 const pageSize=loadAll?null:(([100,200,500] as number[]).includes(numericPageSize)?numericPageSize:200);
 const requestedPage=Math.max(1,Math.trunc(Number(sp.get("page"))||1));
 const knownTotalRaw=sp.get("knownTotal");
 const parsedKnownTotal=knownTotalRaw!==null&&knownTotalRaw!==""?Number(knownTotalRaw):NaN;
 const knownTotalCandidates=Number.isFinite(parsedKnownTotal)
  ?Math.max(0,Math.trunc(parsedKnownTotal))
  :null;
 const c=await getPool().connect();
 try{
  const {stViewParams,initialView,serverViews}=await resolvePlanningView(c,op,areaId);
  const data=await loadPlanningCandidates(c,{
   areaId,op,recipeKey,previousBatchNo,requestedPage,pageSize,stViewParams,
   knownTotalCandidates:pageSize===null?null:knownTotalCandidates
  });
  return NextResponse.json({...data,initialView,serverViews});
 }catch(e){
  return NextResponse.json({error:e instanceof Error?e.message:String(e)},{status:500});
 }finally{c.release();}
}
